<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        // Memanggil tampilan home.php
        return view('home');
    }
}
