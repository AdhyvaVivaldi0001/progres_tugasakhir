<?php

namespace App\Controllers;

use App\Models\BookModel;

class Books extends BaseController
{
    public function index()
    {
        $bookModel = new BookModel();
        $data['books'] = $bookModel->findAll();
        return view('books/index', $data);
    }

    public function create()
    {
        return view('books/create');
    }

    public function store()
    {
        $bookModel = new BookModel();

        $validation = $this->validate([
            'title' => 'required|max_length[255]',
            'author' => 'required|max_length[255]',
            'genre' => 'required|max_length[255]',
            'published_year' => 'required|integer|exact_length[4]',
        ]);

        if (!$validation) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        $bookModel->save([
            'title' => $this->request->getPost('title'),
            'author' => $this->request->getPost('author'),
            'genre' => $this->request->getPost('genre'),
            'published_year' => $this->request->getPost('published_year'),
        ]);

        session()->setFlashdata('message', 'Buku berhasil ditambahkan.');
        return redirect()->to('/books');
    }

    public function edit($id)
    {
        $bookModel = new BookModel();
        $book = $bookModel->find($id);

        if (!$book) {
            session()->setFlashdata('message', 'Buku tidak ditemukan.');
            return redirect()->to('/books');
        }

        $data['book'] = $book;
        return view('books/edit', $data);
    }

    public function update($id)
    {
        $bookModel = new BookModel();

        $data = $this->request->getPost();
        if (!$data || !$bookModel->find($id)) {
            session()->setFlashdata('message', 'Gagal memperbarui buku.');
            return redirect()->to('/books');
        }

        $bookModel->update($id, $data);
        session()->setFlashdata('message', 'Buku berhasil diperbarui.');
        return redirect()->to('/books');
    }

    public function delete($id)
    {
        $bookModel = new BookModel();

        if (!$bookModel->find($id)) {
            session()->setFlashdata('message', 'Buku tidak ditemukan.');
            return redirect()->to('/books');
        }

        $bookModel->delete($id);
        session()->setFlashdata('message', 'Buku berhasil dihapus.');
        return redirect()->to('/books');
    }
}
