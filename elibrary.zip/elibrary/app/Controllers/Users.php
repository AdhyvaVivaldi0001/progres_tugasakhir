<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        // Menampilkan semua pengguna
        $userModel = new UserModel();
        $data['users'] = $userModel->findAll();
        return view('users/index', $data);
    }

    public function create()
    {
        return view('users/create'); // Menampilkan form tambah pengguna
    }

    public function store()
    {
        $userModel = new UserModel();

        // Validasi data input
        $validation = $this->validate([
            'username' => 'required|max_length[255]',
            'email' => 'required|valid_email',
            'password' => 'required|min_length[6]',
        ]);

        if (!$validation) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // Menyimpan data pengguna baru ke dalam database
        $userModel->save([
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT), // Pastikan untuk meng-hash password
        ]);

        // Mengirimkan pesan sukses dan mengarahkan kembali ke halaman daftar pengguna
        session()->setFlashdata('message', 'Pengguna berhasil ditambahkan.');
        return redirect()->to('/users');
    }
}
