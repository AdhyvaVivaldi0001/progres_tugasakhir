<?php
namespace App\Controllers;

use App\Models\LoansModel;
use App\Models\BookModel;
use App\Models\UserModel;

class Loans extends BaseController
{
    public function index()
    {
        $loansModel = new LoansModel();
        $data['loans'] = $loansModel->join('books', 'books.id = loans.book_id')
                                    ->join('users', 'users.id = loans.user_id')
                                    ->select('loans.*, books.title as book_title, users.name as user_name')
                                    ->findAll();
        return view('loans/index', $data);
    }

    public function create()
    {
        $bookModel = new BookModel();
        $userModel = new UserModel();
        $data['books'] = $bookModel->findAll();
        $data['users'] = $userModel->findAll();
        return view('loans/create', $data);
    }

    public function store()
    {
        $loansModel = new LoansModel();
        $data = [
            'book_id' => $this->request->getPost('book_id'),
            'user_id' => $this->request->getPost('user_id'),
            'loan_date' => date('Y-m-d'),
            'status' => 'borrowed',
        ];
        $loansModel->save($data);
        return redirect()->to('/loans');
    }

    public function return($id)
    {
        $loansModel = new LoansModel();
        $loansModel->update($id, [
            'status' => 'returned',
            'return_date' => date('Y-m-d'),
        ]);
        return redirect()->to('/loans');
    }
}
