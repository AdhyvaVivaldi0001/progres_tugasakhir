<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Daftar Peminjaman Buku</h1>
        <a href="/loans/create" class="btn btn-primary mb-3">Tambah Peminjaman</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul Buku</th>
                    <th>Nama Peminjam</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($loans as $loan): ?>
                <tr>
                    <td><?= $loan['id']; ?></td>
                    <td><?= $loan['book_title']; ?></td>
                    <td><?= $loan['user_name']; ?></td>
                    <td><?= $loan['loan_date']; ?></td>
                    <td><?= $loan['return_date'] ?? '-'; ?></td>
                    <td><?= $loan['status']; ?></td>
                    <td>
                        <?php if ($loan['status'] === 'borrowed'): ?>
                            <a href="/loans/return/<?= $loan['id']; ?>" class="btn btn-success btn-sm">Dikembalikan</a>

                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
