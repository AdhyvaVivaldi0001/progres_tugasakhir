<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Peminjaman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Tambah Peminjaman Buku</h1>
        <form action="/loans/store" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label for="book_id" class="form-label">Pilih Buku</label>
                <select name="book_id" id="book_id" class="form-select" required>
                    <?php foreach ($books as $book): ?>
                    <option value="<?= $book['id']; ?>"><?= $book['title']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="user_id" class="form-label">Pilih Pengguna</label>
                <select name="user_id" id="user_id" class="form-select" required>
                    <?php foreach ($users as $user): ?>
                    <option value="<?= $user['id']; ?>"><?= $user['name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</body>
</html>
