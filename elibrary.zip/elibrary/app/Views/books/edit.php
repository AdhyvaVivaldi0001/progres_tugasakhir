<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Edit Buku</h1>

        <!-- Tampilkan pesan jika data tidak valid -->
        <?php if (isset($validation)): ?>
            <div class="alert alert-danger"><?= $validation->listErrors(); ?></div>
        <?php endif; ?>

        <form action="/books/update/<?= $book['id']; ?>" method="post">
            <div class="mb-3">
                <label for="title" class="form-label">Judul Buku</label>
                <input type="text" name="title" id="title" class="form-control" 
                       value="<?= isset($book['title']) ? htmlspecialchars($book['title']) : ''; ?>" required>
            </div>
            <div class="mb-3">
                <label for="author" class="form-label">Penulis</label>
                <input type="text" name="author" id="author" class="form-control" 
                       value="<?= isset($book['author']) ? htmlspecialchars($book['author']) : ''; ?>" required>
            </div>
            <div class="mb-3">
                <label for="year" class="form-label">Tahun Terbit</label>
                <input type="number" name="published_year" id="year" class="form-control" 
                       value="<?= isset($book['published_year']) ? htmlspecialchars($book['published_year']) : ''; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="/books" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>
