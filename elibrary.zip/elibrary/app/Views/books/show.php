<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Buku</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>Detail Buku</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?= $book['title']; ?></h5>
                <h6 class="card-subtitle mb-2 text-muted"><?= $book['author']; ?></h6>
                <p class="card-text">Tahun: <?= $book['year']; ?></p>
                <a href="/books" class="btn btn-secondary">Kembali</a>
            </div>
        </div>
    </div>
</body>
</html>
