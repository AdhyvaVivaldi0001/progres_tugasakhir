<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard eLibrary</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">eLibrary</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/users">Pengguna</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/books">Buku</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/loans">Loans</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center">Selamat Datang di eLibrary</h1>
        <p class="text-center">Kelola Buku dan Pengguna dengan Mudah</p>
        <div class="d-flex justify-content-center mt-4">
            <a href="/books" class="btn btn-primary me-2">Lihat Buku</a>
            <a href="/users" class="btn btn-secondary me-2">Lihat Pengguna</a>
            <a href="/loans" class="btn btn-secondary me-2">Lihat Penyewa</a>
        </div>
    </div>
</body>
</html>
