<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index'); // Halaman utama

// Rute Users ADHYVA 23.230.0001
$routes->get('/users', 'Users::index'); // Menampilkan daftar pengguna
$routes->get('/users/create', 'Users::create'); // Menampilkan form tambah pengguna
$routes->post('/users/store', 'Users::store'); // Menyimpan data pengguna ke database
$routes->get('users/edit/(:num)', 'Users::edit/$1');
$routes->post('users/update/(:num)', 'Users::update/$1');
$routes->get('users/delete/(:num)', 'Users::delete/$1');


// Rute Books ADHYVA 23.230.0001
$routes->get('/books', 'Books::index'); // Menampilkan daftar buku
$routes->get('/books/create', 'Books::create'); // Menampilkan form tambah buku
$routes->post('/books/store', 'Books::store'); // Menyimpan data buku ke database
$routes->get('books/(:num)', 'Books::show/$1');
$routes->get('books/delete/(:num)', 'Books::delete/$1');
$routes->get('books/edit/(:num)', 'Books::edit/$1');  // Menampilkan form edit buku
$routes->post('books/update/(:num)', 'Books::update/$1');  // Memproses update buku



// Rute Loan ADHYVA 23.230.0001
$routes->get('/loans', 'Loans::index');
$routes->get('/loans/create', 'Loans::create');
$routes->post('/loans/store', 'Loans::store');
$routes->get('/loans/return/(:num)', 'Loans::return/$1');
